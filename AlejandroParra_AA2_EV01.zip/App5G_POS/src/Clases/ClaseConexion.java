/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;   

/**
 *
 * @author Usuario
 */
public class ClaseConexion {
    public String Usuario = "root"; 
    // root es el usuario por defecto del gestor de BD
    public String Contrasena ="";
    //Como no hay contraseña, vamos a dejarla en blanco
    public String URL = "jdbc:mysql://localhost:3306/5gpos";
    Connection conexion;
    
    public ClaseConexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) { 
            Logger.getLogger(ClaseConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            conexion = DriverManager.getConnection(URL, Usuario, Contrasena);

        } catch (SQLException ex) {
            Logger.getLogger(ClaseConexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
       }
    public Connection getConnection(){
        return conexion;
 
    
        }
    }
/**
 *
 * @author Usuario
 */

