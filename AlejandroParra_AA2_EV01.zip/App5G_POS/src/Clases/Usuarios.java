package Clases;

import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Usuario
 */
public class Usuarios {
    
    private String Nombre;
    private String Apellido;
    private int IdUsuario;
    private int TelefonoUsuario;
    private String NombreUsuario;
    private String ContrasenaUsuario;
    private String EmailUsuario;
    private String RolUsuario;
    
    // Getter y setter para el atributo Nombre. 
    public String getNombre(){
        return Nombre;
    }
    public void setNombre(String nombre){
        this.Nombre = nombre;
    }
    
    // Getter y setter para el atributo Apellido. 
    public String getApellido(){
        return Apellido;
    }
    public void setApellido(String apellido){
        this.Apellido = apellido;
    }
    
    // Getter y setter para el atributo Usuario
    public int getIdUsuario(){
        return IdUsuario; 
    }
    public void setIdUsuario(int idusuario){
        this.IdUsuario = idusuario;
    }
    
    // Getter y setter para el atributo 
    public int getTelefonoUsuaurio(){
        return TelefonoUsuario;
    }
    public void setTelefonoUsuario(int telefonousuario){
        this.TelefonoUsuario = telefonousuario; 
    }
    
    public String getNombreUsuario(){
        return NombreUsuario; 
    }
    public void setNombreUsuario(String nombreusuario){
        this.NombreUsuario = nombreusuario;
    }
    
    public void setContrasenaUsuario(String claveusuario){
        this.ContrasenaUsuario = claveusuario; 
    }
    
    public String getEmailusuario(){
        return EmailUsuario;
    }
    public void setEmailUsuario(String emailusuario){
        this.EmailUsuario = emailusuario; 
    }
    
    public String getRolUsuario(){
        return RolUsuario;
    }
    public void setRolUsuario(String rolusuario){
        this.RolUsuario = rolusuario; 
    }
    
    // Función que verifica si el usuario se encuentra registrado y la información que ingresó es válida. 
    public void VerificarUsuario(int idUsuario, String contrasenaUsuario){
        if (this.IdUsuario == idUsuario && this.ContrasenaUsuario.equals(contrasenaUsuario)){
        JOptionPane.showMessageDialog(null, "Bienvenido" + this.NombreUsuario);
        }
        else{
            JOptionPane.showMessageDialog(null, "El usuario o contraseña ingresados no son válidos.");
        }
    }
}
